import { USER_ROUTES } from './user/user.route';
import { ModuleWithProviders } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./home-component.component";
import { UserComponent } from "./user/user.component";


const APP_ROUTES: Routes = [
    { path: 'user', redirectTo: '/user/1', pathMatch:'full'},
    { path: 'user/:id', component: UserComponent},
    { path: 'user/:id', component: UserComponent, children: USER_ROUTES},    
    { path: '', component: HomeComponent},
    { path: '**', redirectTo: '/user/1', pathMatch:'full'}
];


export const routing: ModuleWithProviders =  RouterModule.forRoot(APP_ROUTES);