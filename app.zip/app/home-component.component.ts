import { Component } from '@angular/core';

@Component({
  selector: 'app-home-component',
  template: `
    <h1>
      Home Component!
    </h1>
  `,
  styles: []
})
export class HomeComponent {

}
