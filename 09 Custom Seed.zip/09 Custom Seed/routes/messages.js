var express = require('express');
var router = express.Router();
var jwt = require('jsonwebtoken');

var User = require('../models/user');
var Message = require('../models/messages');

router.get('/',function(req,res,next){
    Message.find()
        .populate('user', 'email')
        .exec(function(err,messages){
            if (err){
                return res.status(500).json({
                    title:'An error occurred',
                    error: err
                });
            }
            res.status(200).json({
                message:'Success',
                obj:messages
            });
        });

});

router.use('/',function(req,res,next){
    jwt.query(req.query.token, 'secret', function(err,decoded){
        if (err){
            return res.status(401).json({
                title:'Not Authenticated',
                error:err
            });
        }
        next();
    })
})

router.patch('/:id', function(req, res, next){
    var decoded = jwt.decode(req.query.token);
    Message.findById(req.params.id,function(err, message){
        if (err){
            return res.status(500).json({
                title:'An error occured',
                error:err
            });
        }
        if (!message){
            return res.status(500).json({
                title:'No message found',
                error:{message: 'Message not found'}
            });
        }
        if (message.user != decoded.user_id){
            return res.status(401).json({
                title:'Not Authenteciated',
                error:{Message:'User not match'}
            });
        }
        message.content = req.body.content;
        message.save(function(err, result){
            if (err){
                return res.status(500).json({
                    title:'An error occurred',
                    error: err
                });
            }
            res.status(200).json({
                message:'Updated message',
                obj:result
            });
        });
    });
});

router.delete('/:id', function(req,res,next){
    var decoded = jwt.decode(req.query.token);
    Message.findById(req.params.id, function(err, message){
        if (err){
            return res.status(500).json({
                title:'An error occurred',
                error: err
            });
        }
        if (!message){
            return res.status(500).json({
                title:'No message Found!',
                error:{message: 'Message not Found!'}
            });
        }
        if (message.user != decoded.user._id){
            return res.status(401).json({
                title:'Not Antuehnticated',
                error: {message:'User does not match'}
            });
        }
        message.remove(function(err,result){
            if (err){
                return res.status(500).json({
                    title:'An error Occurred',
                    error:err
                });
            }
            res.status(200).json({
                message:'Delete message successfully',
                obj: result
            });
        });
    });
});

module.exports = router;

